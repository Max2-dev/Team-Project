-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2023 at 11:53 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `pid`, `name`, `price`, `quantity`, `image`) VALUES
(4, 3, 2, 'Laptop', 800, 1, 'laptop-1.webp'),
(5, 3, 1, 'Camera', 645, 1, 'camera-1.webp'),
(6, 3, 3, 'Fridge', 1000, 1, 'fridge-1.webp'),
(7, 3, 4, 'Mixer', 125, 1, 'mixer-1.webp');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Category_id` int(11) NOT NULL,
  `Category_name` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Category_id`, `Category_name`) VALUES
(1, 'laptop'),
(2, 'tv'),
(3, 'consoles'),
(4, 'pcaccessory'),
(5, 'videogames'),
(6, 'headphones'),
(7, 'smartphone'),
(8, 'misc');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `user_id`, `name`, `email`, `number`, `message`) VALUES
(3, 5, 'Jamil', 'jamil108@outlook.com', '07787412026', 'DOES THIS WORK');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `number` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `method` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `total_products` varchar(1000) NOT NULL,
  `total_price` int(100) NOT NULL,
  `placed_on` date NOT NULL DEFAULT current_timestamp(),
  `payment_status` varchar(20) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `name`, `number`, `email`, `method`, `address`, `total_products`, `total_price`, `placed_on`, `payment_status`) VALUES
(1, 4, 'qwewq', '0778741202', 'jamil108@outlook.com', 'credit card', ' no. 90 Church Hill Road, Handsworth, Birmingham, West Midlands, United Kingdom - B20 3PB', 'Laptop (800 x 1) - ', 800, '2023-12-09', 'pending'),
(2, 5, 'Jamil', '0778741202', 'attempt@outlook.com', 'credit card', ' no. attempt, attemptland, Birmingham, attempt county, United Kingdom - A77 EMT', 'Laptop (800 x 1) - realme C21y smartphone (150 x 1) - ', 950, '2023-12-11', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `details` varchar(500) NOT NULL,
  `price` int(10) NOT NULL,
  `image_01` varchar(100) NOT NULL,
  `image_02` varchar(100) NOT NULL,
  `image_03` varchar(100) NOT NULL,
  `Category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `details`, `price`, `image_01`, `image_02`, `image_03`, `Category_id`) VALUES
(1, 'PS5 Slim', 'The Slim model for the PS5 with 1TB of storage.', 645, 'ps5slim-1.webp', 'ps5slim-2.webp', 'ps5slim-3.webp', 3),
(2, 'HP Laptop', 'HP laptop with AMD graphics', 600, 'laptop-1.webp', 'laptop-2.webp', 'laptop-3.webp', 1),
(3, 'Apple Lightning to USB cable', 'USB-2 cable that can be used for charging or to transfer. ', 10, 'applecable-1.webp', 'applecable-2.webp', 'applecable-1.jpg', 8),
(4, '(50% Off) MSI Vigor GK80 Gaming Keyboard', 'A superb gaming keyboard made by renowned manufacturer MSI.\r\n\r\nUsed to be $150, buy before sale ends!', 75, 'msigk80-1.png', 'msigk80-2.png', 'msigk80-3.png', 4),
(5, 'DELL MS116 Mouse', 'DELL Mouse', 16, 'mouse-1.webp', 'mouse-2.webp', 'mouse-3.webp', 4),
(6, 'realme C21y smartphone', 'phone with 6000mah battery 50mp camera', 150, 'smartphone-1.webp', 'smartphone-2.webp', 'smartphone-3.webp', 7),
(7, 'Oneplus Y1S Edge', '8K HDR', 599, 'tv-01.webp', 'tv-02.webp', 'tv-03.webp', 2),
(8, 'Titan Watch', 'A great watch!', 120, 'watch-1.webp', 'watch-2.webp', 'watch-3.webp', 8),
(9, 'iPhone Pro Max 15 ', 'The newest model of iPhone at a reliable price!', 1499, 'iphonepromax-1.webp', 'iphonepromax.webp', 'iphonepromax.webp', 7),
(10, 'Cuphead for Nintendo Switch', 'The hit run and gun indie action game for Nintendo Switch!', 30, 'cupheadswitch-1.jpg', 'cupheadswitch-2.jpg', 'cuphead-3.jpg', 5),
(11, 'Cuphead for Xbox One', 'Cuphead for Xbox One or Xbox Series Consoles.', 30, 'cupheadxbox-1.jpg', 'cupheadxbox-2.jpg', 'cuphead-3.jpg', 5),
(12, '(30% Off) Spiderman 2', 'The newest game by Insomniac games and the next entry in the Spiderman Series on Offer RIGHT NOW! Originally priced at £60', 42, 'spiderman2-1.webp', 'spiderman2-2.webp', 'spiderman2-3.webp', 5),
(13, 'Steelseries Rival 5', 'A well-rounded mouse for gamers.', 33, 'steelseriesrival5-1.webp', 'steelseriesrival5-2.webp', 'steelseriesrival5-3.webp', 4),
(14, 'Xbox Series X', 'The flagship Xbox console! The model comes with 1TB of external memory.', 450, 'xboxseriesx-1.png', 'xboxseriesx-2.png', 'xboxseriesx-3.png', 3),
(15, 'The Legend of Zelda - Tears of the Kingdom', 'The sequel to the hit-game Legend of Zelda - Breath of the Wild, this new entry elevates the series with new powers such as Fuse and Ultrahard to aid the exploration of Hyrule.', 60, 'zeldatotk-1.jpg', 'zeldatotk-2.jpg', 'zeldatotk-3.jpg', 5);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(1, 'Datt ', '19212@oncampus.global', '40bd001563085fc35165329ea1ff5c5ecbdbbeef'),
(3, 'usernametest', 'e@a.com', '9d4e1e23bd5b727046a9e3b4b7db57bd8d6ee684'),
(4, 'jamil', 'jamil108@outlook.com', 'ac1c591e5e49a324e00ff5bc2e564a2b74f104d6'),
(5, 'attempt', 'attempt@outlook.com', '38e4e4b0ad783ff9a801bdfb16c33f64b72beab4');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Category_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Category_id` (`Category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `pid` (`pid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `products` (`id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`Category_id`) REFERENCES `category` (`Category_id`);

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`pid`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
