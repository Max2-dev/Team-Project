<?php

include 'components/connect.php';

session_start();

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
} else {
    $user_id = '';
};

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>

    <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
    
   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    
<?php include 'components/user_header.php'; ?>

<div class="about">
    <div class="content">
        <h1>About T32 Games</h1>
        <p>Welcome to T32 Games, your go-to source for the latest video games and gaming technology. We specialize in offering a wide variety of top-quality games and the newest gaming gear to enthusiasts and casual players alike.</p>
        <p>Our team, passionate about all things gaming, carefully selects products to ensure you have access to the best the industry has to offer. From popular titles to cutting-edge gaming consoles, T32 Games is your destination for your gaming needs.</p>
        <p>Discover the latest trends in gaming technology and explore our diverse selection of games. At T32 Games, we're dedicated to enhancing your gaming experience with exceptional products and knowledgeable service.</p>
        <a href="contact.php" class="btn">contact us</a>
    </div>
</div>

<div class="reviews">
    <h1 class="heading">client's reviews</h1>

    <div class="swiper reviews-slider">
        <div class="swiper-wrapper">
            <div class="swiper-slide slide">
                <img src="images/pic-1.png" alt="">
                <p>Nice! Good products.</p>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Alice</h3>
            </div>

            <div class="swiper-slide slide">
                <img src="images/pic-2.png" alt="">
                <p>Really good products</p>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Deona</h3>
            </div>

     

        </div>
        <div class="swiper-pagination"></div>
    </div>
</div>

<?php include 'components/footer.php'; ?>

<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>
<script src="js/script.js"></script>

<script>
    var swiper = new Swiper(".reviews-slider", {
        loop: true,
        spaceBetween: 20,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        breakpoints: {
            0: {
                slidesPerView: 1,
            },
            768: {
                slidesPerView: 2,
            },
            991: {
                slidesPerView: 3,
            },
        },
    });
</script>

</body>
</html>