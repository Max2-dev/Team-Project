<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['signedup'])){

   $name = $_POST['username'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['psw']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);
   $cpass = sha1($_POST['cfmpsw']);
   $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

   $select_user = $conn->prepare("SELECT * FROM `users` WHERE email = ?");
   $select_user->execute([$email,]);
   $row = $select_user->fetch(PDO::FETCH_ASSOC);

   if($select_user->rowCount() > 0){
      $message[] = 'Email already exists!';
   }else{
      if($pass != $cpass){
         $message[] = 'Confirm password not matched!';
      }else{
         $insert_user = $conn->prepare("INSERT INTO `users`(name, email, password) VALUES(?,?,?)");
         $insert_user->execute([$name, $email, $cpass]);
         $message[] = 'Registered successfully, Login now please!';
      }
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register</title>
   
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>




<section id="signup-section">
    <div class="container">
      <form id="signup" class="frm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
        <header class="frmheader">Welcome to T32 Games</header>
        <p>Sign Up</p>
        <p>Please fill in this form to sign up</p>

        <label for="email">Email Address</label>
        <input type="email" id="email" name="email" class="un_input" placeholder="Email" pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" required>

        <label for="username">Username</label>
        <input type="text" placeholder="Enter Username" class="un_input" name="username" required>

        <label for="psw">Password</label>
        <input type="password" placeholder="Enter Password" class="un_input" name="psw" required>

        <label for="cfmpsw">Confirm Password</label>
        <input type="password" placeholder="Confirm Password" class="un_input" name="cfmpsw" required>

        <button type="submit" name="signedup" class="frmbtn" id="signupbtn" onclick="checkPassword()">Sign Up</button>

        <span>Already have an account? <a href="user_login.php" class="link"> Log In</a></span>
      </form>
    </div>
</section>

<script>
let form = document.getElementById("signup");
let first_pass = form.psw;
let confirm_pass = form.cfmpsw;


first_pass.onsubmit = checkPassword();
confirm_pass.onsubmit = checkPassword();

// Function to check that users 2 passwords match on the form
function checkPassword(){
    let form = document.getElementById("signup");

    let first_pass = form.psw;
    let confirm_pass = form.cfmpsw;
    let errors = '';
    
    if(first_pass.value === confirm_pass.value) {
        first_pass.setCustomValidity('');
    } else {
        errors += "Passwords Must Match";
    }
    
    first_pass.setCustomValidity(errors);
    first_pass.reportValidity();
}
</script>








<?php include 'components/footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>