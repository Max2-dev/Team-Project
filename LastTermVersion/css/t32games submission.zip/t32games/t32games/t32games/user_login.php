<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['login'])){

   $username = $_POST['username'];
   $username = filter_var($username, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);

   $select_user = $conn->prepare("SELECT * FROM `users` WHERE name = ? AND password = ?");
   $select_user->execute([$username, $pass]);
   $row = $select_user->fetch(PDO::FETCH_ASSOC);

   if($select_user->rowCount() > 0){
      $_SESSION['user_id'] = $row['id'];
      header('location:home.php');
   }else{
      $message[] = 'incorrect username or password!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>login</title>
   
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>


<section id="login-section">
  <div class="container">
    <form class="frm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
      <header class="frmheader">Welcome</header>
      <p>Log in</p>
      <p>Please fill in this form to log in</p>

      <label for="username">Username</label>
      <input type="text" placeholder="Enter Username" class="un_input" name="username" required>

      <label for="psw">Password</label>
      <input type="password" placeholder="Enter Password" class="un_input" name="pass" required>
          
      <button type="submit" name="login" id="loginbtn" class="frmbtn">Log in</button>

      <span>Create a new Account? <a href="user_signup.php" class="link"> Sign up</a></span>
      <span id="adm">Click to <a href="#" class="link">Log in as Admin</a></span>
      
    </form>
  </div>
</section>




<?php include 'components/footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>